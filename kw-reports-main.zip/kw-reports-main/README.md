# kw-reports
FiveM report system
- Uses Discord webhooks for reports.
- Send playername, current id and discord id on report.
- Bugs and suggestions on Discord @kwzkw

![kuva](https://github.com/Kwamppi/kw-reports/assets/150602846/312259ec-a664-4af5-a96f-f07b441a5442)
![kuva](https://github.com/Kwamppi/kw-reports/assets/150602846/895eefb1-0f12-4ade-a263-a48b2160ea47)


